# -*- coding: utf-8 -*-

from .widget import ANCHOR_NUMBER, ANCHOR_NUMBERS
from .widget import Number, RandomInt, Summer, Multiplier, SubprocessSummer, DataFieldExample, MyWidget, Clicker

# Define legit links
ANCHORS = [
    (False, ANCHOR_NUMBER, ANCHOR_NUMBER),
    (False, ANCHOR_NUMBER, ANCHOR_NUMBERS),
    (False, ANCHOR_NUMBERS, ANCHOR_NUMBERS),
]

# Define groups of widgets
WIDGETS = [
    "Input",
    ("#80c0ff", Number, "icon/Number.png"),
    ("#80c0ff", RandomInt, "icon/RandomNumber.png"),
    "Task",
    ("#c0c0ff", Summer, "icon/Summer.png"),
    ("#c0c0ff", Multiplier, "icon/Multiplier.png"),
    ("#c0c0ff", SubprocessSummer,),
    "Examples",
    ("#c0ffc0", DataFieldExample,),
    ("#c0ffc0", MyWidget,),
    "Test",
    ("#ffc0ff", Clicker,),
]
