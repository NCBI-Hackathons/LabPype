# -*- coding: utf-8 -*-

from .widget import ANCHOR_NUMBER, ANCHOR_NUMBERS
from .widget import Number, RandomInt, Summer, Multiplier, SubprocessSummer, DataFieldExample, MyWidget

# Define legit links
ANCHORS = [
    (False, ANCHOR_NUMBER, ANCHOR_NUMBER),
    (False, ANCHOR_NUMBER, ANCHOR_NUMBERS),
    (False, ANCHOR_NUMBERS, ANCHOR_NUMBERS),
]

# Define groups of widgets
WIDGETS = [
    "Input",
    ("#80c0ff", Number, "icon/Number.png"),
    ("#80c0ff", RandomInt, "icon/RandomNumber.png"),
    "Task",
    ("#c080ff", Summer, "icon/Summer.png"),
    ("#c080ff", Multiplier, "icon/Multiplier.png"),
    ("#c080ff", SubprocessSummer,),
    "Examples",
    ("#c080ff", DataFieldExample,),
    ("#c080ff", MyWidget,),
]
