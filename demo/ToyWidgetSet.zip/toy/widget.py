# -*- coding: utf-8 -*-

import os
import threading
import subprocess
from random import randint
from time import sleep

from labpype.widget import Widget, ANCHOR_REGULAR
from labpype.widget.field import *

# Import the dialogs for our widgets
from . import dialog as Di

# Get the path of the application
MAIN_PATH = os.path.dirname(os.path.realpath(__file__))
Here = lambda f="": os.path.join(MAIN_PATH, f)


# Define some anchor types here
class ANCHOR_NUMBER(ANCHOR_REGULAR):
    pass


class ANCHOR_NUMBERS(ANCHOR_REGULAR):
    pass


# Here we define some widgets
class Number(Widget):
    NAME = "Number"
    DIALOG = "V"
    INTERNAL = FloatField(key="NUMBER", label="")
    OUTGOING = ANCHOR_NUMBER

    def Name(self):
        if self["OUT"] is not None:
            return str(self["OUT"])

    def Task(self):
        return self["NUMBER"]


class RandomInt(Widget):
    NAME = "Random Integer"
    DIALOG = "V"
    INTERNAL = IntegerField(key="MIN", label="Min"), IntegerField(key="MAX", label="Max")
    OUTGOING = ANCHOR_NUMBER

    def Name(self):
        if self["OUT"] is not None:
            return str(self["OUT"])

    def Task(self):
        return randint(self["MIN"], self["MAX"])


class Summer(Widget):
    NAME = "Summer"
    DIALOG = Di.Number
    THREAD = True
    INCOMING = ANCHOR_NUMBERS, "NUMBERS", True, "LTB", "Number"
    OUTGOING = ANCHOR_NUMBER

    def Name(self):
        if self.IsState("Done"):
            return "+".join(str(i) for i in self["NUMBERS"]) + "=" + str(self["OUT"])

    def Task(self):
        t = threading.currentThread()
        p = 0
        for i in self["NUMBERS"]:
            sleep(0.5)
            t.CheckPoint()
            p += i
        return p


class Multiplier(Widget):
    NAME = "Multiplier"
    DIALOG = Di.Number
    THREAD = True
    INCOMING = ANCHOR_NUMBERS, "NUMBERS", True, "LTB", "Number"
    OUTGOING = ANCHOR_NUMBER

    def Name(self):
        if self.IsState("Done"):
            return "*".join(str(i) for i in self["NUMBERS"]) + "=" + str(self["OUT"])

    def Task(self):
        t = threading.currentThread()
        p = 1
        n = len(self["NUMBERS"])
        for index, i in enumerate(self["NUMBERS"]):
            sleep(1)
            t.CheckPoint(index + 1, n)
            p *= i
        return p


class SubprocessSummer(Widget):
    NAME = "Subprocess Summer"
    DIALOG = {"ORIENTATION": "V", "SIZE": (120, -1)}
    THREAD = True
    INCOMING = ANCHOR_NUMBERS, "NUMBERS", True, "LTB", "Number"
    OUTGOING = ANCHOR_NUMBER

    def Name(self):
        if self.IsState("Done"):
            return str(self["OUT"])

    def Task(self):
        t = threading.currentThread()
        p = subprocess.Popen(["python", Here("dummyprocess.py"), *(str(i) for i in self["NUMBERS"])], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        while p.poll() is None:
            sleep(1)
            if t.stop:
                p.kill()
                t.CheckPoint()
        if p.returncode == 0:
            return float(p.stdout.read().strip())
